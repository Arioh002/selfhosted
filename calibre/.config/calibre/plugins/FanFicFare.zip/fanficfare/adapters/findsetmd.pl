
$flag=0;
$curfile='';

while(<>) {
    if($curfile ne $ARGV) {
        $flag=0;
        $curfile=$ARGV
    }
    if(/def getChapterText/) {
        $flag=1;
    }
    if(/setMetadata/ && $flag) {
        print("$ARGV $_")
    }
}
